import os
import numpy as np

# Parameter settings
NUM_SAMPLES = 26  # Number of samples
TIME_STEPS = 100  # Time steps (T)
#DEM_SIZE = (32, 32)  # Spatial size of DEM data (X, Y)

# Randomly generate rainfall data (rainfall intensity 0-100 mm)
#rainfall_data = np.random.uniform(0, 100, size=(NUM_SAMPLES, TIME_STEPS, 1)).astype(np.float32)

ppet_folder_path = "./petptrain/"  # Replace with your folder path
asc_file_path = "./pjdem.asc"  # Replace with your ASC file path
rainfall_output_file = "rainfall_data.npy"  # Output file name for rainfall data
evaporation_output_file = "evaporation_data.npy"  # Output file name for evaporation data
dem_output_file = "dem_data.npy"  # Output file name for DEM data

flood_folder_path = "./floodtrain/"  # Replace with your folder path
flood_output_file = "target_data.npy"  # Output file name for flood data

# Store rainfall and evaporation data
rainfall_data = []
evaporation_data = []

# Iterate through all the txt files in the folder

for file_name in sorted(os.listdir(ppet_folder_path), key=lambda x: int(x.split('_')[0])):
    if file_name.endswith(".txt"):  # Only process txt files
        file_path = os.path.join(ppet_folder_path, file_name)
        print(file_path)
        data = np.loadtxt(file_path)  # Assuming the file is separated by spaces or tabs
        rainfall_data.append(data[:TIME_STEPS, 0])  # The first column is rainfall data, first 100 rows
        evaporation_data.append(data[:TIME_STEPS, 1])  # The second column is evaporation data
        # Add the current file's data, adjust the shape to (T, 1)


# Combine all the data from the files
rainfall_data = np.expand_dims(np.array(rainfall_data), axis=-1)  # Shape: (12, T, 1)
evaporation_data = np.expand_dims(np.array(evaporation_data), axis=-1)  # Shape: (12, T, 1)

# Save as .npy files




# Read the ASC file content and parse it into a numpy array
with open(asc_file_path, 'r') as file:
    for _ in range(6):  # Skip the first 6 lines
        next(file)
    dem_data = np.loadtxt(file)  # Read the raster data part

# Copy 12 times and adjust the shape to (NUM_SAMPLES, N, M, 1)
raster_data = np.tile(dem_data, (NUM_SAMPLES, 1, 1))  # Copy 12 times, shape becomes (12, N, M)
raster_data = np.expand_dims(raster_data, axis=-1)  # Add the last dimension, shape becomes (12, N, M, 1)

# Save as .npy files


# Store all subfolder data
all_data = []

# Iterate through all subfolders in the parent folder, sorting them by number
for sub_folder_name in sorted(os.listdir(flood_folder_path),  key=lambda x: int(x[2:])):
    sub_folder_path = os.path.join(flood_folder_path, sub_folder_name)
    if os.path.isdir(sub_folder_path):  # Ensure it's a directory
        sub_folder_data = []

        # Iterate through all files in the subfolder, first filtering out .asc files
        asc_files = [f for f in os.listdir(sub_folder_path) if f.endswith('.wd')]
        
        # Sort by the number part of the filename, ensuring they are read in order
        asc_files = sorted(asc_files, key=lambda x: int(x.split('.')[0].split('-')[1]))  # Assuming file name format is gts1975-0001.asc
        asc_files = asc_files[:TIME_STEPS]   # Time scale
        # Read the sorted .asc files
        for file_name in asc_files:
            file_path = os.path.join(sub_folder_path, file_name)
            print(file_path)
            # Read ASC file content and skip header information (assuming header is 6 lines)
            with open(file_path, 'r') as file:
                for _ in range(6):  # Skip the first 6 lines
                    next(file)
                data = np.loadtxt(file)  # Read the raster data part
            sub_folder_data.append(data)

        # Stack the subfolder data into (T, N, M)
        sub_folder_data = np.array(sub_folder_data)  # Shape: (T, N, M)
        all_data.append(sub_folder_data)

# Stack all subfolder data into (n, T, N, M)
all_data = np.array(all_data)  # Shape: (n, T, N, M)

# Save as .npy files

np.save(rainfall_output_file, rainfall_data)
np.save(evaporation_output_file, evaporation_data)
np.save(dem_output_file, raster_data)
np.save(flood_output_file, all_data)

print(f"Combined data has been saved to {flood_output_file}, data shape: {all_data.shape}")
print(f"Raster data has been saved to {dem_output_file}, data shape: {raster_data.shape}")
print(f"Rainfall data has been saved to {rainfall_output_file}, data shape: {rainfall_data.shape}")
print(f"Evaporation data has been saved to {evaporation_output_file}, data shape: {evaporation_data.shape}")


# Randomly generate DEM data (elevation 0-500 m)
#dem_data = np.random.uniform(0, 500, size=(NUM_SAMPLES, DEM_SIZE[0], DEM_SIZE[1], 1)).astype(np.float32)
# Randomly generate target flood depth data (depth 0-10 m)
#target_data = np.random.uniform(0, 10, size=(NUM_SAMPLES, TIME_STEPS, DEM_SIZE[0], DEM_SIZE[1])).astype(np.float32)
print("Input data has been generated and saved.")
