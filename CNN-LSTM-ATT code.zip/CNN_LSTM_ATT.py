import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from keras.models import Model
from keras.layers import Input, LSTM, Dense, Conv2D, MaxPooling2D, Flatten, Concatenate, Reshape
from sklearn.model_selection import train_test_split

from keras import layers, models
from keras.optimizers import Adam
import time 
from sklearn.preprocessing import StandardScaler

from keras.callbacks import ReduceLROnPlateau
plt.rcParams['font.family'] = 'Times New Roman'

# Set up a learning rate reduction strategy
lr_reduction = ReduceLROnPlateau(monitor='val_loss', patience=3, factor=0.1, min_lr=1e-6)

# Load dataset
rainfall_data = np.load('rainfall_data.npy')  # Shape: (n, 100, 1)
evaporation_data = np.load('evaporation_data.npy')  # Shape: (n, 100, 1)
terrain_data = np.load('dem_data.npy')  # Shape: (n, N, M, 1)
target_data = np.load('target_data.npy')  # Shape: (n, 100, N, M)

scaler = StandardScaler()

# Split dataset into training and testing sets
X_rain, X_rain_test, X_evap, X_evap_test, X_terrain, X_terrain_test, y_train, y_test = train_test_split(
    rainfall_data, evaporation_data, terrain_data, target_data, test_size=0.1, random_state=42)

# Convert data types to float32 for model training
X_rain = X_rain.astype(np.float32)
X_evap = X_evap.astype(np.float32)
X_terrain = X_terrain.astype(np.float32)
y_train = y_train.astype(np.float32)

# Build LSTM model for processing time-series data
def build_lstm_model(input_shape):
    model = models.Sequential()
    model.add(layers.LSTM(4, activation='relu', input_shape=input_shape, return_sequences=False))
    model.add(layers.Dropout(0.3))  # Dropout layer to reduce overfitting
    model.add(layers.Dense(4, activation='relu'))
    model.add(layers.Dense(4))  # Output layer
    return model

# Initialize LSTM models for rainfall and evaporation data
rainfall_model = build_lstm_model(X_rain.shape[1:])
evaporation_model = build_lstm_model(X_evap.shape[1:])

# Build CNN model for processing spatial terrain data
def build_cnn_model(input_shape):
    model = models.Sequential()
    model.add(layers.Conv2D(8, (3, 3), activation='relu', input_shape=input_shape))
    model.add(layers.MaxPooling2D((3, 3)))  # Pooling layer
    model.add(layers.Conv2D(8, (3, 3), activation='relu'))
    model.add(layers.MaxPooling2D((3, 3)))
    model.add(layers.Flatten())
    model.add(layers.Dense(8, activation='relu'))
    return model

# Initialize CNN model for terrain data
terrain_model = build_cnn_model(X_terrain.shape[1:])

from keras.layers import Attention, Concatenate
from keras.utils import plot_model

# Build an attention-based model combining LSTM and CNN outputs
def build_attention_model(rain_model, evap_model, terrain_model, time_steps, n, m):
    # Extract outputs from individual models
    lstm_output = rain_model.output
    evap_output = evap_model.output
    cnn_output = terrain_model.output

    # Concatenate features from all models
    merged = Concatenate()([lstm_output, evap_output, cnn_output])

    # Apply attention mechanism
    attention = Attention()([merged, merged])

    # Flatten the attention output and pass through dense layers
    attention_output = layers.Flatten()(attention)
    attention_output = layers.Dense(8, activation='relu')(attention_output)

    # Reshape the output to match the required prediction dimensions [batch_size, T, N, M]
    output = layers.Dense(time_steps * n * m)(attention_output)
    output = layers.Reshape((time_steps, n, m))(output)

    # Define the model with three inputs and one output
    model = models.Model(inputs=[rain_model.input, evap_model.input, terrain_model.input], outputs=output)
    return model

# Define spatial and temporal dimensions
time_steps = 100  # Predicting 100 time steps
n = X_terrain.shape[1]  # Spatial dimension N of terrain data
m = X_terrain.shape[2]  # Spatial dimension M of terrain data

# Create final model
from keras.losses import Huber
final_model = build_attention_model(rainfall_model, evaporation_model, terrain_model, time_steps, n, m)

# Compile the model with optimizer and loss function
final_model.compile(optimizer='adam', loss='mse', metrics=['mae'])

from keras.callbacks import EarlyStopping
early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

# Visualize and save model architecture
plot_model(final_model, to_file='model_with_attention.png', show_shapes=True, show_layer_names=True)

# Display model structure as an image
plt.figure(figsize=(10, 10), dpi=450)
plt.imshow(plt.imread('model_with_attention.png'))
plt.axis('off')

# Train the model
starttime1 = time.time()
history = final_model.fit(
    [X_rain, X_evap, X_terrain], y_train, 
    validation_data=([X_rain_test, X_evap_test, X_terrain_test], y_test), 
    epochs=50, 
    batch_size=2  # Use a small batch size to reduce computational load
)
endtime1 = time.time()
traintime = endtime1 - starttime1 
print(f"Training completed in {traintime:.2f} seconds.")

# Save trained model
final_model.save('flood_prediction_model39.h5')

# Save training history
np.save('training_history.npy', history.history)

# Plot training loss and MAE curves
plt.figure(figsize=(12, 6))

# Plot Loss
plt.subplot(1, 2, 1)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs', fontsize=16)
plt.ylabel('Loss', fontsize=16)
plt.title('Model Loss', fontsize=17)
plt.legend(fontsize=14)

# Plot MAE
plt.subplot(1, 2, 2)
plt.plot(history.history['mae'], label='Training MAE')
plt.plot(history.history['val_mae'], label='Validation MAE')
plt.xlabel('Epochs', fontsize=16)
plt.ylabel('MAE', fontsize=16)
plt.title('Model MAE', fontsize=17)
plt.legend(fontsize=14)

plt.tight_layout()
plt.savefig('training_loss_mae_curve.png', dpi=500)
plt.show()

# Load trained model
final_model = models.load_model('flood_prediction_model39.h5')

# Load test data
X_rain_test = np.load('rainfall_data_test.npy')
X_evap_test = np.load('evaporation_data_test.npy')
X_terrain_test = np.load('dem_data_test.npy')
y_test = np.load('target_data_test.npy')

# Perform predictions
startime2 = time.time()
predictions = final_model.predict([X_rain_test, X_evap_test, X_terrain_test])
endtime2 = time.time()
testtime2 = endtime2 - startime2
print(f"Test completed in {testtime2:.2f} seconds.")

# Calculate error metrics
mse = np.mean((predictions - y_test) ** 2)
mae = np.mean(np.abs(predictions - y_test))

print(f'Mean Squared Error (MSE): {mse}')
print(f'Mean Absolute Error (MAE): {mae}')

# Generate comparison plots
import os
output_dir = "comparison_plots"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

num_floods, num_hours, N, M = y_test.shape

for hour in range(num_hours):
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 2, 1)
    plt.imshow(y_test[0, hour, :, :], cmap='viridis')
    plt.title(f'Flood 1 Ground Truth\nHour {hour+1}')
    
    plt.subplot(2, 2, 2)
    plt.imshow(predictions[0, hour, :, :], cmap='viridis')
    plt.title(f'Flood 1 Prediction\nHour {hour+1}')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'comparison_hour_{hour:03d}.png'))
    plt.close()

print(f"Generated {num_hours} comparison plots, saved in '{output_dir}'.")
