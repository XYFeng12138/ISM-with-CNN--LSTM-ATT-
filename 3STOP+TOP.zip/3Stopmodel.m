% Observational data
load('PER0311LV.mat');

input1 = addfinal_PER{fileName}(:,7:9);
[kk, mm] = size(input1);
input = input1(1:kk,:); % Select training data
R = input(:,1); % Rainfall (m)
PE = input(:,2); % Evaporation capacity (m)
% QOBS = input(:,3).*3.6./6448./1000; % Measured runoff depth (m)
QOBS = input(:,3); % Measured runoff depth (m)
nstep = length(R); % Sequence length
DT = 1; % Time step

% Terrain index
smap = importdata('dx_pj.txt'); % Input data (.txt: sum of areas with the same terrain index value)
ac = smap(:,1); % Terrain index distribution, i.e., the sum of areas with the same terrain index value (different locations)
st = smap(:,2); % Terrain index value: LN(A/TANB) (terrain index needs to be arranged from large to small), i.e., the median value of divided intervals
nac = length(ac); % Terrain index sequence length

% Terrain index area integration
A = sum(ac); % Total area of the watershed
ac = ac / A; % The proportion of area with the same terrain index value at different locations
TL = sum(ac .* st); % Terrain index area * corresponding area proportion

% Model parameters
T0 = x(1); % T0: Saturated hydraulic conductivity (m^2/h)
SZM = x(2); % SZM: Maximum storage depth in the unsaturated zone (m)
SRMAX = x(3); % SRMAX: Maximum storage capacity in the root zone (m)
TD = x(4); % TD: Time lag parameter for gravitational drainage (h/m)
SR0 = x(5); % SR0: Initial water content in the vegetation root zone (m)
Q0 = x(6); % Q0: Initial interflow (m/time step)
kmus = x(7); % kmus: Surface Muskingum root parameter
xmus = x(8); % xmus: Surface Muskingum root parameter
recharge_coeff = x(9); % Interflow recharge coefficient, determining what proportion of interflow recharges groundwater runoff
ci = x(10); % Linear reservoir interflow storage coefficient
Kb = x(11); % Kb: Linear reservoir groundwater runoff recession coefficient

% Initialize variable values
SZQ = A * T0 * exp(-TL); % SZQ is the flow when SBAR is zero, SBAR is the initial average saturated groundwater deficit depth

% Initialize soil water storage
SUZ = zeros(nac,1); % Initial water content in the unsaturated zone is 0
SRZ = ones(nac,1) * SR0; % Initial soil water content in the root zone, i.e., the initial soil water deficit
if Q0 < eps(1)
    Q0 = 0.0001;
end
% SBAR = -(a1/CN) * log(Q0/SZQ); % Initial average saturated groundwater deficit depth
SBAR = -SZM * log(Q0/SZQ);
if SBAR < 0
    SBAR = eps(1);
end
QIN = ones(nstep,1) * Q0; % Initial flow is baseflow

% Initialize water balance equation
SUMP = 0; % Cumulative rainfall
SUMEA = 0; % Infiltration rate
SUMQ = 0; % Cumulative flow

% Initialize source area
QUZ = zeros(nstep,1); % Infiltration rate (water in the unsaturated zone vertically enters the saturated groundwater layer at a certain rate)
EA = zeros(nstep,1); % Actual evaporation
QOF = zeros(nstep,1); % Saturated surface runoff
QF = zeros(nstep,1); % Interflow free water

% Initialize runoff variables
% Runoff calculation
for i = 1:nstep
    EP = PE(i); % EP is the evaporation capacity for the period, replaced by the actual surface evaporation at the watershed observation station
    P = R(i); % P is the rainfall amount for the period
    SUMP = SUMP + P; % Cumulative rainfall
    EX = zeros(nac,1); % EX is the infiltration excess
    SD = zeros(nac,1); % Soil water deficit at local watershed points
    UZ = zeros(nac,1); % Soil water deficit at local watershed points
    
    % Start looping through the terrain index increment (no infiltration excess in this version)
    for j = 1:nac
        % Calculate local water deficit depth
        % SD(j) = SBAR - (a1/CN) * (st(j) - TL);
        SD(j) = SBAR - SZM * (st(j) - TL);
        if SD(j) <= 0
            SD(j) = 0;
        end
        
        % Vegetation root zone calculation
        SRZ(j) = SRZ(j) - P;
        if SRZ(j) < 0
            SUZ(j) = SUZ(j) - SRZ(j);
            SRZ(j) = 0;
        end
        
        % Unsaturated zone calculation
        if SUZ(j) > SD(j)
            EX(j) = SUZ(j) - SD(j);
            SUZ(j) = SD(j);
        end
        
        % Calculate infiltration rate
        if SD(j) > 0
            UZ(j) = SUZ(j) / (SD(j) * TD) * DT;
            if UZ(j) > SUZ(j)
                UZ(j) = SUZ(j);
            end
            SUZ(j) = SUZ(j) - UZ(j);
            if SUZ(j) < 0
                SUZ(j) = 0;
            end
            QUZ(i) = QUZ(i) + UZ(j) * ac(j);
        end
        
        % Calculate actual evaporation
        if EP > 0
            EA(i) = EP * (1 - SRZ(j) / SRMAX);
            if EA(i) > (SRMAX - SRZ(j))
                EA(i) = SRMAX - SRZ(j);
            end
            SRZ(j) = SRZ(j) + EA(i);
            SUMEA = SUMEA + EA(i) * ac(j);
        end
        
        % Calculate saturated surface runoff (assume terrain index is arranged from high to low)
        OF = 0;
        if j > 1
            if EX(j) > 0
                % Both limits are saturated
                OF = ac(j) * (EX(j) + EX(j - 1)) / 2;
            elseif EX(j - 1) > 0
                % Check if lower limit saturated (higher a/tanB value)
                OF = ac(j) * EX(j - 1) / 2;
            end
        end
        QOF(i) = QOF(i) + OF;
    end
    % All terrain units completed

    % Calculate interflow
    % QF(i) = SZQ * exp(-SBAR / (a1 / CN)); % for CN value from Pingjiang 86
    QF(i) = SZQ * exp(-SBAR / SZM);
    if QF(i) < 0
        QF(i) = 0;
    end
    SBAR = SBAR - QUZ(i) + QF(i);
    QIN(i) = QF(i) + QOF(i); % Output flow
    SUMQ = SUMQ + QIN(i);
end

% Muskingum parameter calculation for runoff routing
c1 = (0.5 * DT + kmus * xmus) / (0.5 * DT + kmus - kmus * xmus);
c2 = (0.5 * DT - kmus * xmus) / (0.5 * DT + kmus - kmus * xmus);
c3 = 1 - c1 - c2;

Qb = zeros(nstep,1); % Initialize storage volume array
Qg = zeros(nstep,1); % Initialize groundwater runoff outflow array
Qft = zeros(nstep,1);
for z = 1:nstep
    if z == 1
        Qg(z) = Q0 * recharge_coeff; % Initial groundwater runoff is the initial interflow of the watershed
        Qb(z) = Q0 * (1 - recharge_coeff);
        Qft(z) = QOF(1);
    else
        % Update surface runoff using Muskingum method
        Qft(z) = max(c1 * QOF(z - 1) + c2 * QOF(z) + c3 * Qft(z - 1), 0);
    end
    % Calculate two parts of interflow
    recharge_flow = max(QF .* recharge_coeff, 0); % Part that recharges groundwater runoff
    direct_flow = max(QF .* (1 - recharge_coeff), 0); % Part that directly forms outflow
    
    % Use linear reservoir model to calculate baseflow
    for t = 1:length(recharge_flow)
        if t > 1
            Qg(t) = max(Kb * Qg(t - 1) + DT * (1 - Kb) * (recharge_flow(t - 1)), 0); % Linear reservoir Kb groundwater
            Qb(t) = max(ci * Qb(t - 1) + DT * (1 - ci) * (direct_flow(t - 1)), 0); % Linear reservoir ci interflow
        end
    end
end

% Assign to final flow variable
QOUT = Qft + Qg + Qb;
Qt = QOUT .* 0.36 .* DT ./ A;
Qt(1) = 0;
area = 484.467916046662;
obs = QOBS * 1000 / (3.6 / area);
mod = Qt * 1000 / (3.6 / area);
R = R * 1000;

% Return
