load('PER0311YZ.mat');
fileName = fileName;
input1=addfinal_PER{fileName}(:,7:9);
% input1 = data_source; % Input data (.txt: rainfall, evaporation capacity, observed runoff depth)
[kk mm]=size(input1);
input=input1(1:kk,:); % Select training data
R = input(:,1); % Rainfall (m)
PE = input(:,2); % Evaporation capacity (m)
% QOBS = input(:,3).*3.6./6448./1000; % Observed runoff depth (m)
QOBS = input(:,3); % Observed runoff depth (m)
nstep = length(R); % Sequence length
DT = 1; % Time step

% Terrain index
smap = importdata('dx_pj.txt'); % Input data (.txt: sum of areas at the same location of terrain index values, terrain index)
ac = smap(:,1); % Terrain index distribution, i.e., sum of areas with the same terrain index value at different locations
st = smap(:,2); % Terrain index values: LN(A/TANB) (terrain index needs to be sorted from large to small), which are the middle values after segmentation
nac = length(ac); % Terrain index sequence length

% Terrain index area integral calculation
A = sum(ac); % Total watershed area
ac = ac/A; % Proportion of area with the same terrain index value at different locations
TL = sum(ac.*st); % Terrain index area * corresponding area proportion

%% Model parameters (9 parameters)

T0 = x(1); % T0: saturated hydraulic conductivity (m^2/h)
SZM = x(2); % SZM: maximum water storage depth in the unsaturated zone (m)
SRMAX = x(3); % SRMAX: maximum water storage in the root zone (m)
TD = x(4); % TD: time lag parameter for gravity drainage (h/m)
SR0 = x(5); % SR0: initial water content in the vegetation root zone (m)
Q0 = x(6); % Q0: initial interflow (m/time step)
K = x(7); % K: linear reservoir storage-discharge coefficient
n = x(8); % YY: number of linear reservoirs
Kb = x(9); % Kb: groundwater runoff recession coefficient
% x=[17.6837    0.2993    0.3000   97.2765    0.0478    0.0502    7.9569    1.0000    0.2521];

%% Initialize variables
SZQ = A*T0*exp(-TL); % SZQ is the flow when SBAR is zero, SBAR is the initial average saturated groundwater deficit

% Initialize soil water storage
SUZ = zeros(nac,1); % Initial soil water content in the unsaturated zone is 0
SRZ = ones(nac,1)*SR0; % Soil water content in the vegetation root zone, i.e., initial soil deficit
if Q0 < eps(1)
    Q0 = 0.00001;
end
SBAR = -SZM * log(Q0/SZQ); % Initial average saturated groundwater deficit
if SBAR < 0
    SBAR = eps(1);
end
QOUT = ones(nstep,1)*Q0; % Initial flow is base flow

% Initialize water balance equation
BAL = -SBAR - SR0; % Initial average saturated groundwater deficit and initial soil deficit
SUMP = 0; % Cumulative rainfall
SUMEA = 0; % Infiltration rate
SUMQ = 0; % Cumulative flow

% Initialize source area
QUZ = zeros(nstep,1); % Infiltration rate (water in the unsaturated zone enters the saturated groundwater zone at a certain rate)
EA = zeros(nstep,1); % Actual evaporation
QOF = zeros(nstep,1); % Saturated overland flow
QB = zeros(nstep,1); % Interflow

%% Runoff calculation
for i = 1 : nstep
    EP = PE(i); % EP is the evaporation capacity for the period, replaced by actual water surface evaporation from the watershed observation station
    P = R(i); % P is the rainfall for the period
    SUMP = SUMP + P; % Cumulative rainfall
    EX = zeros(nac,1); % EX is
    SD = zeros(nac,1); % Local soil deficit in the watershed
    UZ = zeros(nac,1); % Local soil deficit in the watershed, i.e., soil infiltration rate

% Start the loop for the terrain index increment (this version does not have infiltration excess)
% ACM = 0
   for j = 1:nac-1
%         ACF = 0.5*(ac(j)+ac(j+1));
% Calculate local deficit depth
        SD(j) = SBAR - SZM * (st(j)-TL);
        if SD(j) <= 0 
           SD(j)=0;
        end
% Vegetation root zone storage
        SRZ(j) = SRZ(j) - P; % When rainfall cannot meet the deficit in the root zone

% Calculate actual evaporation (evaporation occurs in the root zone, evaporation needs to be deducted when calculating unsaturated zone storage)
         if EP > 0 
            EA(i) = EP * (1 - SRZ(j)/SRMAX);
            if EA(i) > (SRMAX - SRZ(j))
                EA(i) = SRMAX - SRZ(j);    
            end 
         end
         SRZ(j) = SRZ(j) + EA(i);
         SUMEA = SUMEA + EA(i) * ac(j); % Total evaporation  
% After the root zone is saturated, calculate the next layer of inactive water storage
         if SRZ(j)<0  % Root zone saturated, but inactive layer is not yet saturated
           SUZ(j) = SUZ(j) - SRZ(j);
           SRZ(j) = 0;
         end
         
         % Calculate infiltration rate
        if SD(j) > 0
           UZ(j) = SUZ(j)/(SD(j)*TD)*DT;
           if UZ(j) > SUZ(j)
              UZ(j) = SUZ(j);
           end
           SUZ(j) = SUZ(j) - UZ(j);
           if SUZ(j) < 0.0000001 
              SUZ(j) = 0;
           end
           QUZ(i) = QUZ(i) + UZ(j) * ac(j); % Total infiltration rate of the watershed
        end
        % Calculate unsaturated layer storage after infiltration
        if SUZ(j) > SD(j)   % Unsaturated zone is saturated
           EX(j) = SUZ(j) - SD(j);
           SUZ(j) = SD(j);
        end         

% Calculate saturated overland flow (assuming terrain index is sorted from high to low)
       OF = 0;  
       if j > 1
          if EX(j) > 0
        % Both limits are saturated
%              OF = ac(j) * EX(j);
              OF = ac(j) * (EX(j) + EX(j-1))/2;
%              ACM = ACM + ac(j)
          % Check if lower limit saturated (higher a/tanB value)
          elseif EX(j-1) > 0 
              ac(j) = ac(j)*EX(j-1)/(EX(j-1)-EX(j));
              OF = ac(j) * EX(j-1)/2;
%               ACM = ACM + ACF
           end
        end
       QOF(i) = QOF(i) + OF;
    end
% Completion of terrain unit calculation for the watershed
    
% Calculate interflow
    QB(i) = SZQ * exp(-SBAR/SZM);
    if QB(i) < 0 
        QB(i) = 0;
    end
    SBAR = SBAR - QUZ(i)+QB(i);
    QOUT(i) = QB(i) + QOF(i); % Output flow
    SUMQ = SUMQ + QOUT(i);
    % End of all time period calculations
end
% Water balance equation calculation
SUMRZ = 0; % Final soil deficit
SUMUZ = 0; % Final saturated zone water content
for j=1:nac-1
    SUMRZ = SUMRZ + SRZ(j) * ac(j);
    SUMUZ = SUMUZ + SUZ(j) * ac(j);
end
% Final water balance calculation
BAL1 = BAL + SBAR + SUMP - SUMEA - SUMQ + SUMRZ - SUMUZ;

%% Flow calculation
% Surface runoff calculation (using Nash instantaneous unit hydrograph)
% Nash instantaneous unit hydrograph calculation
SUMU = 0;
U = zeros(nstep,1);
for i = 1:nstep
    t = (i-1)*DT;
    T = t - DT;
    if T < 0
       T = 0;
    end
    U(i) = gamcdf(t,n,K) - gamcdf(T,n,K); % Unit hydrograph for time step DT and unit rainfall of 1mm
    SUMU = SUMU + U(i);
    if SUMU == 1
        U(U==0) = [];   
        break
    end
   h = U*A/3.6/DT; % Unit hydrograph for a time step DT and net rainfall of 1mm
end
% Unit hydrograph calculation completed

H = conv(QOF,h); % Convolution to obtain surface runoff
Qft = H(1:nstep,1); % Extract the flow that matches the time series length
Qt = zeros(nstep,1);
Qbt = zeros(nstep,1);
Qbt(1) = Q0; % Initial groundwater runoff is the initial interflow of the watershed
Qt(1) = Qbt(1);
for i = 2 : nstep
    Qbt(i) = Kb * Qbt(i-1) + (1 - Kb) * QB(i) * A / 3.6 / DT; % Groundwater runoff calculation formula
end
Qt = Qft + Qbt;
Qt = Qt .* 3.6 .* DT ./ A;

area = 484.467916046662;
obs = QOBS * 1000 / (3.6 / area); 
mod = Qt * 1000 / (3.6 / area);
R = R * 1000;
