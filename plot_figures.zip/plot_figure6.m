load('ACOOM_lv_118.mat');
names = {'19710606';'19720506';'19730528';'19770517';'19780803';'19790611';'19800412';'19810601';'19820512';'19830515';'19840427';...
'19860713';'19880525';'19890619';'19920624';'19930502';'19940421';'19990812';'20000402';'20020720';'20050623';'20060526';'20070610';...
'20080626';'20120624'};

suffixes = 'abcdefghijklmnopqrstuvwxyz';

sorted_names_with_suffix = cell(length(names), 1);


for i = 1:length(names)
    sorted_names_with_suffix{i} = strcat('(', suffixes(i), ')', names{i});
end

% 显示结果
disp(sorted_names_with_suffix);
figure;
hold on;
for cc=1:length(A_co_OM)

    subplot(8,3,cc);
    X_axis=1:length(A_co_OM{cc}(:,9));
    y1_axis=A_co_OM{cc}(:,9);%模拟值
    y2_axis=A_co_OM{cc}(:,7);%降雨量
    y3_axis=A_co_OM{cc}(:,8);%实测值
    y4_axis=A_co_OM{cc}(:,10);%模拟值对比
    JG_P=ceil(max(y2_axis)/4);JG_R=ceil(max(y1_axis)/4);
    hold on;
   % figure(cc) 
    [AX,H1,H2] =plotyy(X_axis,y3_axis,X_axis,y2_axis,'plot','bar');%画双轴，AX(1)左轴，AX（2）右轴，H为曲线本身 
    hold on
    H4=plot(y1_axis); %好
    hold on
    H3 = plot( X_axis,y4_axis,'Color',[0.20 0.69 0.28],'lineStyle','--'); %差
    hold on 
    %设置坐标轴刻度
    set(gca,'box','off','Ytick',[])
    set(AX(2),'YDir','reverse','Ylim',[0,max(y2_axis)*2],'YTick',[0:JG_P:max(y2_axis)],'FontSize',7.5,'FontName','times new Roman');  %设置右边轴为倒立,设置左y轴右边数据范围（0到最大值的2倍），刻度显示（0,0.002,0.004...max(pre_obs)*2）
    set(AX(1),'YLim',[0,max(y3_axis)*2],'YTick',[0:JG_R:max(y3_axis)],'Fontsize',7.5,'FontName','times new Roman','YColor','k');
    %设置坐标轴的标题
   % set(get(AX(1),'Xlabel'),'String','Time (h)','FontName','times new Roman','FontSize',8);
    %set(get(AX(1),'Ylabel'),'String','Discharge (m^3/s)','FontName','times new Roman','FontSize',8);
    %set(get(AX(2),'Ylabel'),'string','Precipitation (mm)','FontName','times new Roman','FontSize',8);

    %设置figuer中线，柱的属性
    set(H2,'BarWidth',0.8,'FaceColor',[0.12 0.65 1],'EdgeColor','none');
    set(H1,'LineWidth',0.8,'Color','k');  %设置H1的曲线宽为0.5，颜色为g绿色,
    set(H4,'LineWidth',0.8,'Color','r','Linestyle','--');
  
    %设置背景色和图例
    set(gcf,'color','w');  %设置当前figure的背景颜色
    title(sorted_names_with_suffix{cc},'FontSize',8.5,'FontName','times new Roman');
    if cc == 1
        legend([H2,H1,H3,H4],'Precipitation','Observed Flow','Topmodel','3S-Topmodel','Location','northeast');  
        legend('FontSize', 8,'Position',[0.065,0.07,0.9,0.01],'NumColumns',4,'Box','off');  % 改变图例的大小和位置
    else
        legend off; % 其他子图不显示图例
    end

    if cc <= 21  % 前 7 行不显示 x 轴标题
       AX(1).XLabel.String = [];
    else
       set(get(AX(1),'Xlabel'),'String','Time (h)','FontName','times new Roman','FontSize',8);
    end

    if  mod(cc, 3) ~= 1 % 前 7 行不显示 x 轴标题
       AX(1).YLabel.String= [];
    else
       set(get(AX(1),'Ylabel'),'String','Discharge (m^3/s)','FontName','times new Roman','FontSize',7.5);
    end

    if  mod(cc, 3) ~= 0 % 前 7 行不显示 x 轴标题
       AX(2).YLabel.String = [];
    else
       set(get(AX(2),'Ylabel'),'string','Precipitation (mm)','FontName','times new Roman','FontSize',7.5);
    end

    hold on ;
 
end

set(gcf, 'Position', [1, 1, 700, 2400]);  % [left, bottom, width, height]1

hold off;
outputFileName = 'subplot_image2.png'; % 输出文件名
resolution = 600; % 指定分辨率，单位为 DPI（每英寸点数）

% 使用print函数保存图片，设置分辨率
print(outputFileName, '-dpng', ['-r', num2str(resolution)]); % 以300 DPI保存为PNG格式图片